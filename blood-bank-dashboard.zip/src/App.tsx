/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo, useEffect } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  Legend, Cell, PieChart, Pie 
} from 'recharts';
import { 
  LayoutDashboard, 
  Calendar, 
  Users, 
  Droplet, 
  TrendingUp, 
  Globe, 
  Moon, 
  Sun, 
  Languages 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { RAW_DATA, TRANSLATIONS } from './constants';
import { Language, YearFilter, DataRecord } from './types';
import { cn } from './lib/utils';

export default function App() {
  const [lang, setLang] = useState<Language>('ar');
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [yearFilter, setYearFilter] = useState<YearFilter>('all');

  const t = TRANSLATIONS[lang];
  const isRtl = lang === 'ar';

  useEffect(() => {
    document.documentElement.setAttribute('dir', isRtl ? 'rtl' : 'ltr');
    document.documentElement.setAttribute('data-lang', lang);
    document.documentElement.setAttribute('data-theme', theme);
  }, [lang, theme, isRtl]);

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

  // Logic helpers
  const getDonation = (r: DataRecord, y: YearFilter) => {
    if (y === '2023') return r.d23;
    if (y === '2024') return r.d24;
    if (y === '2025') return r.d25;
    return r.d23 + r.d24 + r.d25;
  };

  const getDonor = (r: DataRecord, y: YearFilter) => {
    if (y === '2023') return r.r23;
    if (y === '2024') return r.r24;
    if (y === '2025') return r.r25;
    return r.r23 + r.r24 + r.r25;
  };

  const filteredData = RAW_DATA; // Raw data is same, we filter columns in calculations

  // KPI Calculations
  const stats = useMemo(() => {
    const donorsSum = filteredData.reduce((acc, r) => acc + getDonation(r, yearFilter), 0);
    const casesSum = filteredData.reduce((acc, r) => acc + getDonor(r, yearFilter), 0);
    const convRate = donorsSum > 0 ? (casesSum / donorsSum) * 100 : 0;

    const omaniMaleDonors = filteredData.filter(r => r.nat === 'OMANI' && r.sex === 'MALE').reduce((acc, r) => acc + getDonation(r, yearFilter), 0);
    const omaniFemaleDonors = filteredData.filter(r => r.nat === 'OMANI' && r.sex === 'FEMALE').reduce((acc, r) => acc + getDonation(r, yearFilter), 0);
    const nonOmaniMaleDonors = filteredData.filter(r => r.nat === 'NON_OMANI' && r.sex === 'MALE').reduce((acc, r) => acc + getDonation(r, yearFilter), 0);
    const nonOmaniFemaleDonors = filteredData.filter(r => r.nat === 'NON_OMANI' && r.sex === 'FEMALE').reduce((acc, r) => acc + getDonation(r, yearFilter), 0);

    const omaniMaleCases = filteredData.filter(r => r.nat === 'OMANI' && r.sex === 'MALE').reduce((acc, r) => acc + getDonor(r, yearFilter), 0);
    const omaniFemaleCases = filteredData.filter(r => r.nat === 'OMANI' && r.sex === 'FEMALE').reduce((acc, r) => acc + getDonor(r, yearFilter), 0);
    const nonOmaniMaleCases = filteredData.filter(r => r.nat === 'NON_OMANI' && r.sex === 'MALE').reduce((acc, r) => acc + getDonor(r, yearFilter), 0);
    const nonOmaniFemaleCases = filteredData.filter(r => r.nat === 'NON_OMANI' && r.sex === 'FEMALE').reduce((acc, r) => acc + getDonor(r, yearFilter), 0);

    const omaniDonors = omaniMaleDonors + omaniFemaleDonors;
    const nonOmaniDonors = nonOmaniMaleDonors + nonOmaniFemaleDonors;
    const omaniCases = omaniMaleCases + omaniFemaleCases;
    const nonOmaniCases = nonOmaniMaleCases + nonOmaniFemaleCases;

    return {
      totalDonations: donorsSum, // Mapping sum of 'd' (17041) to label "إجمالي المتبرعين"
      totalDonors: casesSum,     // Mapping sum of 'r' (14619) to label "الحالات المقبولة"
      convRate,
      omaniMaleDonors,
      omaniFemaleDonors,
      nonOmaniMaleDonors,
      nonOmaniFemaleDonors,
      omaniMaleCases,
      omaniFemaleCases,
      nonOmaniMaleCases,
      nonOmaniFemaleCases,
      omaniDonors,
      nonOmaniDonors,
      omaniCases,
      nonOmaniCases
    };
  }, [yearFilter, filteredData]);

  // Chart Data: Age Groups & Gender (Total Donors - 17041 path)
  const ageChartData = useMemo(() => {
    const ageGroups: ('18-24' | '25-44' | '45-64' | '65+')[] = ['18-24', '25-44', '45-64', '65+'];
    return ageGroups.map(age => {
      const omaniMale = RAW_DATA.find(r => r.nat === 'OMANI' && r.sex === 'MALE' && r.age === age);
      const omaniFemale = RAW_DATA.find(r => r.nat === 'OMANI' && r.sex === 'FEMALE' && r.age === age);
      const nonOmaniMale = RAW_DATA.find(r => r.nat === 'NON_OMANI' && r.sex === 'MALE' && r.age === age);
      const nonOmaniFemale = RAW_DATA.find(r => r.nat === 'NON_OMANI' && r.sex === 'FEMALE' && r.age === age);

      return {
        age,
        [t.omaniMale]: omaniMale ? getDonation(omaniMale, yearFilter) : 0,
        [t.omaniFemale]: omaniFemale ? getDonation(omaniFemale, yearFilter) : 0,
        [t.nonOmaniMale]: nonOmaniMale ? getDonation(nonOmaniMale, yearFilter) : 0,
        [t.nonOmaniFemale]: nonOmaniFemale ? getDonation(nonOmaniFemale, yearFilter) : 0,
      };
    });
  }, [yearFilter, t]);

  // Chart Data: Age Groups & Gender (Accepted Cases - 14619 path)
  const acceptedAgeChartData = useMemo(() => {
    const ageGroups: ('18-24' | '25-44' | '45-64' | '65+')[] = ['18-24', '25-44', '45-64', '65+'];
    return ageGroups.map(age => {
      const omaniMale = RAW_DATA.find(r => r.nat === 'OMANI' && r.sex === 'MALE' && r.age === age);
      const omaniFemale = RAW_DATA.find(r => r.nat === 'OMANI' && r.sex === 'FEMALE' && r.age === age);
      const nonOmaniMale = RAW_DATA.find(r => r.nat === 'NON_OMANI' && r.sex === 'MALE' && r.age === age);
      const nonOmaniFemale = RAW_DATA.find(r => r.nat === 'NON_OMANI' && r.sex === 'FEMALE' && r.age === age);

      return {
        age,
        [t.omaniMale]: omaniMale ? getDonor(omaniMale, yearFilter) : 0,
        [t.omaniFemale]: omaniFemale ? getDonor(omaniFemale, yearFilter) : 0,
        [t.nonOmaniMale]: nonOmaniMale ? getDonor(nonOmaniMale, yearFilter) : 0,
        [t.nonOmaniFemale]: nonOmaniFemale ? getDonor(nonOmaniFemale, yearFilter) : 0,
      };
    });
  }, [yearFilter, t]);

  // Chart Data: Total Donors Gender & Nationality Distribution
  const donorGenderData = useMemo(() => {
    return [
      { name: t.omaniMale, value: stats.omaniMaleDonors, color: 'var(--c2)' },
      { name: t.omaniFemale, value: stats.omaniFemaleDonors, color: 'var(--c4)' },
      { name: t.nonOmaniMale, value: stats.nonOmaniMaleDonors, color: 'var(--c1)' },
      { name: t.nonOmaniFemale, value: stats.nonOmaniFemaleDonors, color: 'var(--c5)' },
    ];
  }, [stats, t]);

  // Chart Data: Accepted Cases Gender & Nationality Distribution
  const acceptedGenderData = useMemo(() => {
    return [
      { name: t.omaniMale, value: stats.omaniMaleCases, color: 'var(--c2)' },
      { name: t.omaniFemale, value: stats.omaniFemaleCases, color: 'var(--c4)' },
      { name: t.nonOmaniMale, value: stats.nonOmaniMaleCases, color: 'var(--c1)' },
      { name: t.nonOmaniFemale, value: stats.nonOmaniFemaleCases, color: 'var(--c5)' },
    ];
  }, [stats, t]);

  // Chart Data: annual comparison
  const annualComparisonData = [
    { name: '2023', [t.donationCases]: RAW_DATA.reduce((acc, r) => acc + r.d23, 0), [t.donors]: RAW_DATA.reduce((acc, r) => acc + r.r23, 0) },
    { name: '2024', [t.donationCases]: RAW_DATA.reduce((acc, r) => acc + r.d24, 0), [t.donors]: RAW_DATA.reduce((acc, r) => acc + r.r24, 0) },
    { name: '2025', [t.donationCases]: RAW_DATA.reduce((acc, r) => acc + r.d25, 0), [t.donors]: RAW_DATA.reduce((acc, r) => acc + r.r25, 0) },
  ];

  const formatNumber = (num: number) => num.toLocaleString(lang === 'ar' ? 'ar-OM' : 'en-US');

  return (
    <div className="flex min-h-screen bg-[var(--bg)] text-[var(--text1)] selection:bg-[var(--accent-dim)] selection:text-[var(--accent)]">
      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 z-50 flex w-72 flex-col border-[var(--border)] bg-[var(--bg2)] shadow-2xl transition-all duration-300",
        isRtl ? "right-0 border-l" : "left-0 border-r"
      )}>
        <div className="flex flex-col gap-8 p-6">
          <div className="flex items-center gap-4">
            <div className="group relative flex h-12 w-12 items-center justify-center rounded-2xl bg-[var(--accent)] text-white shadow-[0_0_20px_rgba(239,68,68,0.4)] transition-transform hover:scale-110">
              <Droplet size={24} fill="currentColor" />
            </div>
            <h1 className="text-xl font-black tracking-tight">{t.sidebarTitle}</h1>
          </div>

          <div className="rounded-2xl border border-[var(--border)] bg-[var(--bg3)] p-4 shadow-sm">
            <p className="text-[12px] font-bold text-[var(--accent-light)] uppercase tracking-wider">{t.deptHealthPlanning}</p>
            <p className="mt-1 text-[11px] text-[var(--text3)] opacity-80">{t.deptInfoManagement}</p>
          </div>

          <nav className="flex flex-col gap-2">
            <p className="px-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--text3)] mb-2">{t.menu}</p>
            <button className="group flex items-center gap-3 rounded-xl px-4 py-3 text-[14px] font-bold transition-all bg-[var(--accent)] text-black shadow-[0_0_20px_rgba(201,255,42,0.15)] hover:shadow-[0_0_25px_rgba(201,255,42,0.25)]">
              <LayoutDashboard size={18} />
              <span>{t.overview}</span>
            </button>
          </nav>

          <div className="flex flex-col gap-4 pt-6 border-t border-[var(--border)]">
            <p className="px-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--text3)]">{t.filterByYear}</p>
            <div className="grid grid-cols-2 gap-3">
              {(['all', '2023', '2024', '2025'] as YearFilter[]).map((y) => (
                <button
                  key={y}
                  onClick={() => setYearFilter(y)}
                  className={cn(
                    "rounded-xl border py-2.5 text-xs font-bold font-mono transition-all",
                    yearFilter === y 
                      ? "bg-white text-black border-white shadow-lg" 
                      : "bg-[var(--bg3)] text-[var(--text2)] border-[var(--border2)] hover:bg-[var(--bg4)] hover:text-white"
                  )}
                >
                  {y === 'all' ? t.allYears : y}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-auto p-6">
          <div className="flex items-center gap-3 rounded-2xl bg-[var(--bg3)] border border-[var(--border)] px-4 py-3">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_#10b981]"></div>
            <div className="flex flex-col text-[10px] font-mono leading-tight">
              <span className="text-[var(--text3)] uppercase tracking-tighter">{t.dataRange}</span>
              <span className="font-bold text-[var(--text1)] mt-0.5">{t.dateRangeValue}</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className={cn(
        "flex flex-1 flex-col transition-all duration-300",
        isRtl ? "mr-72" : "ml-72"
      )}>
        {/* Topbar */}
        <header className="sticky top-0 z-40 flex items-center justify-between border-b border-[var(--border)] bg-[var(--bg2)]/80 backdrop-blur-xl px-10 py-6">
          <div>
            <h2 className="text-2xl font-black tracking-tight">{t.title}</h2>
            <p className="text-xs text-[var(--text3)] font-medium mt-1 uppercase tracking-widest">{t.subtitle}</p>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex p-1 rounded-xl border border-[var(--border2)] bg-[var(--bg3)]">
              <button
                onClick={() => setLang('ar')}
                className={cn("px-5 py-2 rounded-lg text-xs font-bold transition-all", lang === 'ar' ? "bg-[var(--accent)] text-black shadow-md" : "text-[var(--text2)] hover:text-white")}
              >
                ع
              </button>
              <button
                onClick={() => setLang('en')}
                className={cn("px-5 py-2 rounded-lg text-xs font-bold transition-all", lang === 'en' ? "bg-[var(--accent)] text-black shadow-md" : "text-[var(--text2)] hover:text-white")}
              >
                EN
              </button>
            </div>
            
            <button
              onClick={toggleTheme}
              className="flex h-11 w-11 items-center justify-center rounded-xl border border-[var(--border2)] bg-[var(--bg3)] text-[var(--text2)] transition-all hover:bg-white hover:text-black hover:border-white shadow-sm"
            >
              {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
            </button>
          </div>
        </header>

        <div className="p-10">
          {/* KPIs */}
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            <KPICard 
              label={t.totalDonors} 
              value={formatNumber(stats.totalDonors)} 
              tag={yearFilter === 'all' ? "2023–2025" : yearFilter} 
              icon="👤"
              color="blue"
            />
            <KPICard 
              label={t.totalDonations} 
              value={formatNumber(stats.totalDonations)} 
              tag={yearFilter === 'all' ? "2023–2025" : yearFilter} 
              icon="🩸"
              color="teal"
            />
            <KPICard 
              label={t.conversionRate} 
              value={`${Math.round(stats.convRate)}%`} 
              tag={t.conversionRateSub} 
              icon="📊"
              color="amber"
            />
            <KPICard 
              label={t.topAgeGroup} 
              value="25–44" 
              tag={t.topAgeGroupSub} 
              icon="🏅"
              color="rose"
            />
          </div>

          {/* Charts Row 1 - Age Distribution */}
          <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
            <Panel title={t.casesByAgeGender} subtitle={t.combinedComparison}>
              <div className="mb-4 flex flex-wrap gap-4">
                <LegendItem color="var(--c2)" label={t.omaniMale} />
                <LegendItem color="var(--c4)" label={t.omaniFemale} />
                <LegendItem color="var(--c1)" label={t.nonOmaniMale} />
                <LegendItem color="var(--c5)" label={t.nonOmaniFemale} />
              </div>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={ageChartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--gc)" />
                    <XAxis 
                      dataKey="age" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: 'var(--tc)', fontSize: 11 }}
                    />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: 'var(--tc)', fontSize: 11 }}
                      tickFormatter={(val) => val >= 1000 ? `${Math.round(val/1000)}k` : val}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)', borderRadius: '8px' }}
                      itemStyle={{ fontSize: '12px' }}
                    />
                    <Bar dataKey={t.omaniMale} fill="var(--c2)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey={t.omaniFemale} fill="var(--c4)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey={t.nonOmaniMale} fill="var(--c1)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey={t.nonOmaniFemale} fill="var(--c5)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Panel>

            <Panel title={t.acceptedCasesByAgeGender} subtitle={t.combinedComparison}>
              <div className="mb-4 flex flex-wrap gap-4">
                <LegendItem color="var(--c2)" label={t.omaniMale} />
                <LegendItem color="var(--c4)" label={t.omaniFemale} />
                <LegendItem color="var(--c1)" label={t.nonOmaniMale} />
                <LegendItem color="var(--c5)" label={t.nonOmaniFemale} />
              </div>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={acceptedAgeChartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--gc)" />
                    <XAxis 
                      dataKey="age" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: 'var(--tc)', fontSize: 11 }}
                    />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: 'var(--tc)', fontSize: 11 }}
                      tickFormatter={(val) => val >= 1000 ? `${Math.round(val/1000)}k` : val}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)', borderRadius: '8px' }}
                      itemStyle={{ fontSize: '12px' }}
                    />
                    <Bar dataKey={t.omaniMale} fill="var(--c2)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey={t.omaniFemale} fill="var(--c4)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey={t.nonOmaniMale} fill="var(--c1)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey={t.nonOmaniFemale} fill="var(--c5)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Panel>
          </div>

          {/* Gender Distribution Charts */}
          <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
            <Panel title={t.genderDistribution} subtitle={t.malesVsFemales}>
              <div className="relative h-[250px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={donorGenderData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {donorGenderData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)', borderRadius: '8px' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-4 flex flex-wrap justify-center gap-4">
                <LegendItem color="var(--c2)" label={t.omaniMale} />
                <LegendItem color="var(--c4)" label={t.omaniFemale} />
                <LegendItem color="var(--c1)" label={t.nonOmaniMale} />
                <LegendItem color="var(--c5)" label={t.nonOmaniFemale} />
              </div>
            </Panel>

            <Panel title={t.acceptedGenderDistribution} subtitle={t.malesVsFemales}>
              <div className="relative h-[250px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={acceptedGenderData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {acceptedGenderData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)', borderRadius: '8px' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-4 flex flex-wrap justify-center gap-4">
                <LegendItem color="var(--c2)" label={t.omaniMale} />
                <LegendItem color="var(--c4)" label={t.omaniFemale} />
                <LegendItem color="var(--c1)" label={t.nonOmaniMale} />
                <LegendItem color="var(--c5)" label={t.nonOmaniFemale} />
              </div>
            </Panel>
          </div>

          {/* Charts Row 2 */}
          <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
            <Panel title={t.acceptedNationalityDistribution} subtitle={t.omaniVsNonOmani}>
              <div className="flex flex-col gap-6">
                <ProgressBar 
                  label={t.omaniLabel} 
                  value={stats.omaniCases} 
                  total={stats.totalDonors} 
                  color="var(--c2)" 
                  formatNumber={formatNumber}
                />
                <ProgressBar 
                  label={t.nonOmaniLabel} 
                  value={stats.nonOmaniCases} 
                  total={stats.totalDonors} 
                  color="var(--c4)" 
                  formatNumber={formatNumber}
                />

                <div className="mt-4 grid grid-cols-3 gap-2">
                  {['2023', '2024', '2025'].map(y => (
                    <div key={y} className="flex flex-col items-center rounded-xl border border-[var(--border)] bg-[var(--bg3)] p-3 text-center">
                      <span className="text-[10px] font-mono font-bold text-[var(--text3)]">{y}</span>
                      <span className="mt-1 text-sm font-bold font-mono">
                        {formatNumber(RAW_DATA.reduce((acc, r) => acc + (r as any)[`r${y.slice(2)}`], 0))}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </Panel>

            <Panel title={t.nationalityDistribution} subtitle={t.omaniVsNonOmani}>
              <div className="flex flex-col gap-6">
                <ProgressBar 
                  label={t.omaniLabel} 
                  value={stats.omaniDonors} 
                  total={stats.totalDonations} 
                  color="var(--c1)" 
                  formatNumber={formatNumber}
                />
                <ProgressBar 
                  label={t.nonOmaniLabel} 
                  value={stats.nonOmaniDonors} 
                  total={stats.totalDonations} 
                  color="var(--c5)" 
                  formatNumber={formatNumber}
                />

                <div className="mt-4 grid grid-cols-3 gap-2">
                  {['2023', '2024', '2025'].map(y => (
                    <div key={y} className="flex flex-col items-center rounded-xl border border-[var(--border)] bg-[var(--bg3)] p-3 text-center">
                      <span className="text-[10px] font-mono font-bold text-[var(--text3)]">{y}</span>
                      <span className="mt-1 text-sm font-bold font-mono">
                        {formatNumber(RAW_DATA.reduce((acc, r) => acc + (r as any)[`d${y.slice(2)}`], 0))}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </Panel>

            <Panel className="lg:col-span-2" title={t.annualComparison} subtitle={t.casesDonors2325}>
              <div className="mb-4 flex gap-4">
                <LegendItem color="var(--c1)" label={t.donors} />
                <LegendItem color="var(--c2)" label={t.donationCases} />
              </div>
              <div className="h-[250px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={annualComparisonData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--gc)" />
                    <XAxis 
                      dataKey="name" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: 'var(--tc)', fontSize: 11 }}
                    />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: 'var(--tc)', fontSize: 11 }}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)', borderRadius: '8px' }}
                    />
                    <Bar dataKey={t.donors} fill="var(--c1)" radius={[6, 6, 0, 0]} />
                    <Bar dataKey={t.donationCases} fill="var(--c2)" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Panel>
          </div>

          {/* Table */}
          <Panel className="mt-6 overflow-hidden p-0" title={t.detailedTable} subtitle={`${yearFilter === 'all' ? t.allYears : yearFilter} — 13 ${t.records}`}>
            <div className="overflow-x-auto">
              <table className={cn("w-full text-sm", isRtl ? "text-right" : "text-left")}>
                <thead className="bg-[#1b1b21] text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--text3)]">
                  <tr>
                    <th className="px-8 py-5 border-b border-white/5">{t.nationality}</th>
                    <th className="px-8 py-5 border-b border-white/5">{t.gender}</th>
                    <th className="px-8 py-5 border-b border-white/5">{t.ageGroup}</th>
                    {yearFilter === 'all' ? (
                      <>
                        <th className="px-8 py-5 border-b border-white/5">2023 {t.donorsHeader}</th>
                        <th className="px-8 py-5 border-b border-white/5">2023 {t.casesHeader}</th>
                        <th className="px-8 py-5 border-b border-white/5">2024 {t.donorsHeader}</th>
                        <th className="px-8 py-5 border-b border-white/5">2024 {t.casesHeader}</th>
                        <th className="px-8 py-5 border-b border-white/5">2025 {t.donorsHeader}</th>
                        <th className="px-8 py-5 border-b border-white/5">2025 {t.casesHeader}</th>
                      </>
                    ) : (
                      <>
                        <th className="px-8 py-5 border-b border-white/5">{t.cases}</th>
                        <th className="px-8 py-5 border-b border-white/5">{t.donors}</th>
                        <th className="px-8 py-5 border-b border-white/5">{t.convRate}</th>
                      </>
                    )}
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {RAW_DATA.map((row, idx) => {
                    const donations = getDonation(row, yearFilter);
                    const donorsValue = getDonor(row, yearFilter);
                    const cRate = donations > 0 ? Math.round((donorsValue / donations) * 100) : 0;
                    
                    return (
                      <tr key={idx} className="transition-colors hover:bg-white/[0.02]">
                        <td className="whitespace-nowrap px-8 py-5">
                          <span className={cn(
                            "inline-flex items-center rounded-xl px-3 py-1 text-[10px] font-bold border",
                            row.nat === 'OMANI' ? "bg-[var(--accent)] text-black border-[var(--accent)] shadow-sm" : "bg-[var(--bg3)] text-[var(--text1)] border-[var(--border)]"
                          )}>
                            {row.nat === 'OMANI' ? t.omani : t.nonOmani}
                          </span>
                        </td>
                        <td className="whitespace-nowrap px-8 py-5">
                          <span className={cn(
                            "inline-flex items-center rounded-xl px-3 py-1 text-[10px] font-bold border",
                            row.sex === 'MALE' ? "bg-[var(--teal-dim)] text-[var(--teal)] border-[var(--teal-dim)]" : "bg-[var(--rose-dim)] text-[var(--rose)] border-[var(--rose-dim)]"
                          )}>
                            {row.sex === 'MALE' ? t.male : t.female}
                          </span>
                        </td>
                        <td className="whitespace-nowrap px-8 py-5">
                          <span className="rounded-xl border border-[var(--border)] bg-[var(--bg3)] px-3 py-1 font-mono text-[11px] font-black text-[var(--text1)]">
                            {row.age}
                          </span>
                        </td>
                        {yearFilter === 'all' ? (
                          <>
                            <td className="px-8 py-5 font-mono font-black text-[var(--accent-light)] text-base">{formatNumber(row.d23)}</td>
                            <td className="px-8 py-5 font-mono font-bold text-[var(--text1)]">{formatNumber(row.r23)}</td>
                            <td className="px-8 py-5 font-mono font-black text-[var(--accent-light)] text-base">{formatNumber(row.d24)}</td>
                            <td className="px-8 py-5 font-mono font-bold text-[var(--text1)]">{formatNumber(row.r24)}</td>
                            <td className="px-8 py-5 font-mono font-black text-[var(--accent-light)] text-base">{formatNumber(row.d25)}</td>
                            <td className="px-8 py-5 font-mono font-bold text-[var(--text1)]">{formatNumber(row.r25)}</td>
                          </>
                        ) : (
                          <>
                            <td className="px-8 py-5 font-mono font-black text-[var(--accent-light)] text-lg">{formatNumber(donations)}</td>
                            <td className="px-8 py-5 font-mono font-bold text-[var(--text1)] text-lg">{formatNumber(donorsValue)}</td>
                            <td className="px-8 py-5 font-mono font-black text-lg" style={{ color: cRate >= 90 ? 'var(--c2)' : cRate >= 80 ? 'var(--c5)' : 'var(--c4)' }}>
                              {cRate}%
                            </td>
                          </>
                        )}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Panel>
        </div>
      </main>
    </div>
  );
}

function KPICard({ label, value, tag, icon, color }: { label: string, value: string, tag: string, icon: string, color: 'blue' | 'teal' | 'amber' | 'rose' }) {
  const isAccent = color === 'blue';

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "group relative overflow-hidden rounded-[2.5rem] p-8 transition-all hover:scale-[1.02] duration-300",
        isAccent ? "bg-[var(--accent)] text-black shadow-[0_20px_50px_rgba(201,255,42,0.2)]" : "bg-[var(--bg2)] border border-[var(--border)] shadow-xl"
      )}
    >
      <div className="flex justify-between items-start mb-4">
        <span className={cn("text-xs font-bold uppercase tracking-widest", isAccent ? "text-black/60" : "text-[var(--text3)]")}>
          {label}
        </span>
        <div className={cn("flex h-10 w-10 items-center justify-center rounded-2xl text-xl", isAccent ? "bg-black text-[var(--accent)]" : "bg-[var(--bg3)] border border-[var(--border)]")}>
          {icon}
        </div>
      </div>
      
      <div className="flex flex-col">
        <span className={cn("text-4xl font-black tracking-tight", isAccent ? "text-black" : "text-[var(--text1)]")}>{value}</span>
        <div className="mt-4">
          <span className={cn(
            "inline-flex rounded-xl px-3 py-1 text-[11px] font-bold tracking-wider",
            isAccent ? "bg-black/10 text-black/80" : "bg-[var(--accent-dim)] text-[var(--accent-light)] shadow-sm"
          )}>
            {tag}
          </span>
        </div>
      </div>
    </motion.div>
  );
}

function Panel({ children, title, subtitle, className }: { children: React.ReactNode, title: string, subtitle?: string, className?: string }) {
  const hasNoPadding = className?.includes('p-0');
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn("rounded-[2.5rem] border border-[var(--border)] bg-[var(--bg2)] p-10 shadow-2xl transition-all", className)}
    >
      <div className={cn(
        "mb-10 flex justify-between items-start",
        hasNoPadding && "px-10 pt-10"
      )}>
        <div className="flex flex-col gap-1.5 text-right pr-2">
          <h3 className="text-xl font-black text-[var(--text1)] tracking-tight">{title}</h3>
          {subtitle && <p className="text-xs text-[var(--text3)] font-bold uppercase tracking-widest">{subtitle}</p>}
        </div>
        <div className="h-2 w-12 bg-[var(--accent)] rounded-full hidden sm:block"></div>
      </div>
      <div className={cn(hasNoPadding && "pb-4")}>
        {children}
      </div>
    </motion.div>
  );
}

function LegendItem({ color, label }: { color: string, label: string }) {
  return (
    <div className="flex items-center gap-2">
      <div className="h-2 w-2 rounded-sm" style={{ backgroundColor: color }} />
      <span className="text-[11px] font-medium text-[var(--text2)]">{label}</span>
    </div>
  );
}

function ProgressBar({ label, value, total, color, formatNumber }: { label: string, value: number, total: number, color: string, formatNumber: (n: number) => string }) {
  const percentage = total > 0 ? (value / total) * 100 : 0;
  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-baseline justify-between px-1">
        <span className="text-xs font-bold text-[var(--text2)] uppercase tracking-wider">{label}</span>
        <span className="text-xl font-black font-mono text-[var(--text1)]">{formatNumber(value)}</span>
      </div>
      <div className="h-3 overflow-hidden rounded-full border border-[var(--border)] bg-[var(--bg3)]">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 1, ease: 'easeOut' }}
          className="h-full rounded-full shadow-[0_0_10px_rgba(201,255,42,0.1)]" 
          style={{ backgroundColor: color }} 
        />
      </div>
    </div>
  );
}
