export type Nationality = 'OMANI' | 'NON_OMANI';
export type Gender = 'MALE' | 'FEMALE';
export type AgeGroup = '18-24' | '25-44' | '45-64' | '65+';

export interface DataRecord {
  nat: Nationality;
  sex: Gender;
  age: AgeGroup;
  d23: number;
  r23: number;
  d24: number;
  r24: number;
  d25: number;
  r25: number;
}

export type Language = 'ar' | 'en';
export type YearFilter = 'all' | '2023' | '2024' | '2025';
